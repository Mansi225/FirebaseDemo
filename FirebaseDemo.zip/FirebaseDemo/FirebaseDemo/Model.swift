//
//  Model.swift
//  FirebaseDemo
//
//  Created by MAC2 on 21/11/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import Foundation

class artisModel : NSObject
{
    var id: String?
    var name: String?
    var genre: String?
    
    init(id: String?, name: String?, genre: String?)
    {
        self.id = id
        self.name = name
        self.genre = genre
    }
}
