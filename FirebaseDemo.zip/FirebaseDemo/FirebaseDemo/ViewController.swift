

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController ,UITableViewDataSource ,UITableViewDelegate{

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtMobile: UITextField!
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var tbl: UITableView!
    
    var list = [artisModel]()
    var dbref : DatabaseReference!
    var sel : String = ""
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        var artis : artisModel
        artis = list[indexPath.row]
        //print(artis)
        cell.textLabel?.text = artis.name
        cell.detailTextLabel?.text = artis.genre
        return cell
        
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {   var dic : artisModel
        dic = list[indexPath.row]
        //print(dic)
        txtName.text = dic.name
        txtMobile.text = dic.genre
        sel = dic.id ?? "duf"
    }
    
    func getdata()
    {
        dbref.observe(DataEventType.value) { (snapshot) in
            if snapshot.childrenCount > 0
            {   self.list.removeAll()
                 for artists in snapshot.children.allObjects as! [DataSnapshot]
                 {
                    let artistobject = artists.value as! [String:AnyObject]
                    let arname = artistobject["name"]
                    let arid = artistobject["id"]
                    let argenre = artistobject["genre"]
                    let artist = artisModel(id: arid as? String, name: arname as? String, genre: argenre as? String)
                    self.list.append(artist)
                }
            self.tbl.reloadData()
            }
        }
    }
    
    func inser()
    {
        let key = dbref.childByAutoId().key
        let artist = ["id":key,"name":txtName.text!,"genre":txtMobile.text!]
        dbref.child(key ?? "dfhjgj").setValue(artist);
        lbl.text = "Inserted.."
    }

    func update()
    {
        if sel != ""
        {
            let artist = ["id":sel ,"name":txtName.text!,"genre":txtMobile.text!]
            dbref.child(sel ).setValue(artist);
            lbl.text = "Updated.."
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        var ar : artisModel
        ar = list[indexPath.row]
        list.remove(at: indexPath.row)
        dbref.child(ar.id!).removeValue()
        self.tbl.reloadData()
    }
    
    @IBAction func btnUpdate(_ sender: Any)
    {
        update()
        getdata()
    }
    
    @IBAction func btnInsert(_ sender: Any)
    {
        inser()
        getdata()
    }

    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        dbref = Database.database().reference().child("Artist")
        getdata()
    }


}

